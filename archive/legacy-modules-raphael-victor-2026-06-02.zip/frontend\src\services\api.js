import axios from 'axios'

/**
 * Cliente HTTP base.
 * Em desenvolvimento (Vite :5173) o proxy do vite.config.js redireciona
 * /auth/* e /api/* para o Spring em :8150.
 * Em produção (build servido pelo Spring) as chamadas vão para o mesmo origin.
 */
export const authApi = axios.create({
  baseURL: '/',
  withCredentials: true,
  headers: { 'Content-Type': 'application/json' },
})

export const gameApi = axios.create({
  baseURL: '/api',
  withCredentials: true,
  headers: { 'Content-Type': 'application/json' },
})

// Interceptor global: redireciona para login em 401
gameApi.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      window.location.href = '/login.html'
    }
    return Promise.reject(err)
  }
)
