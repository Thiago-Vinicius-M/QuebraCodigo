import { useEffect } from 'react'
import { useSudoku } from './useSudoku.js'
import { SudokuBoard } from './SudokuBoard.jsx'

/**
 * Sudoku — componente raiz.
 * Inicia a partida ao montar e delega toda a renderização para SudokuBoard.
 */
export default function Sudoku() {
  const { state, loading, error, startGame, place, erase, solve, clear, restart } = useSudoku()

  useEffect(() => {
    startGame('easy')
  }, [startGame])

  if (loading && !state) {
    return <p style={{ color: '#8899bb', textAlign: 'center' }}>Carregando…</p>
  }

  if (error && !state) {
    return (
      <div style={{ textAlign: 'center', color: '#ff6b6b' }}>
        <p>{error}</p>
        <button onClick={() => startGame('easy')} style={{ marginTop: 12, cursor: 'pointer' }}>
          Tentar novamente
        </button>
      </div>
    )
  }

  return (
    <SudokuBoard
      state={state}
      onPlace={place}
      onErase={erase}
      onSolve={solve}
      onClear={clear}
      onRestart={restart}
    />
  )
}
