import { motion, AnimatePresence } from 'framer-motion'
import css from './game2048.module.css'

/**
 * Game2048Board — renderiza a grade 4×4 com animações por Framer Motion.
 *
 * Props:
 *   state     — objeto retornado pelo backend (grid, score, gameOver, won, message, canUndo)
 *   onMove    — fn(direction: string) chamada quando o jogador faz um movimento
 *   onUndo    — fn() chamada no botão Desfazer
 *   onRestart — fn() chamada no botão Reiniciar / Jogar Novamente
 */
export function Game2048Board({ state, onMove, onUndo, onRestart }) {
  if (!state) return null

  const { grid, score, canUndo, gameOver, won, message } = state

  function tileClass(value) {
    if (value === 0) return ''
    if (value > 2048) return css['tile-super']
    return css[`tile-${value}`] ?? css['tile-super']
  }

  return (
    <div className={css.wrapper}>
      {/* Placar */}
      <div className={css.scoreRow}>
        <div className={css.scoreBox}>
          <div className={css.scoreLabel}>Pontos</div>
          <div className={css.scoreValue}>{score}</div>
        </div>
      </div>

      {/* Botões */}
      <div className={css.controls}>
        <button className={css.btn} disabled={!canUndo} onClick={onUndo}>
          ↶ Desfazer
        </button>
        <button className={css.btn} onClick={onRestart}>
          ⟳ Reiniciar
        </button>
      </div>

      {/* Grade */}
      <div className={css.boardWrapper}>
        <div className={css.grid}>
          {grid.flat().map((value, idx) => (
            <motion.div
              key={idx}
              className={`${css.cell} ${tileClass(value)}`}
              initial={{ scale: value !== 0 ? 0.85 : 1 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 300, damping: 22 }}
            >
              {value !== 0 ? value : ''}
            </motion.div>
          ))}
        </div>

        {/* Overlay de vitória / derrota */}
        <AnimatePresence>
          {(gameOver || won) && (
            <motion.div
              className={css.overlay}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <div className={css.overlayTitle}>
                {won ? 'Você Venceu! 🎉' : 'Game Over!'}
              </div>
              <div className={css.overlayText}>{message}</div>
              <button className={css.btn} onClick={onRestart}>
                Jogar Novamente
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Instruções */}
      <div className={css.instructions}>
        <p>
          <span className={css.key}>↑</span>{' '}
          <span className={css.key}>↓</span>{' '}
          <span className={css.key}>←</span>{' '}
          <span className={css.key}>→</span>{' '}
          para mover · deslize no celular
        </p>
        <p>Junte peças iguais para chegar em <strong>2048</strong>!</p>
      </div>
    </div>
  )
}
