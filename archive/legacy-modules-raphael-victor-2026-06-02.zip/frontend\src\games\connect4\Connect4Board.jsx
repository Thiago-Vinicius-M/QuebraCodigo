import { motion } from 'framer-motion'
import styles from './connect4.module.css'

const ROWS = 6
const COLS = 7

/**
 * Connect4Board — renderiza o tabuleiro e as peças.
 * Recebe o estado do jogo vindo do backend e dispara onColumnClick.
 */
export default function Connect4Board({ board, onColumnClick, gameOver }) {
  return (
    <div className={styles.board} role="grid" aria-label="Tabuleiro Connect 4">
      {/* Indicadores de coluna (hover) */}
      <div className={styles.columnHints}>
        {Array.from({ length: COLS }, (_, col) => (
          <button
            key={col}
            className={styles.columnBtn}
            onClick={() => !gameOver && onColumnClick(col)}
            disabled={gameOver}
            aria-label={`Jogar na coluna ${col + 1}`}
          >
            ▼
          </button>
        ))}
      </div>

      {/* Grade de células */}
      <div className={styles.grid}>
        {Array.from({ length: ROWS }, (_, row) =>
          Array.from({ length: COLS }, (_, col) => {
            const value = board?.[row]?.[col] ?? null
            return (
              <div key={`${row}-${col}`} className={styles.cell}>
                {value && (
                  <motion.div
                    className={`${styles.piece} ${styles[value.toLowerCase()]}`}
                    initial={{ y: -40 * row, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                  />
                )}
              </div>
            )
          })
        )}
      </div>
    </div>
  )
}
