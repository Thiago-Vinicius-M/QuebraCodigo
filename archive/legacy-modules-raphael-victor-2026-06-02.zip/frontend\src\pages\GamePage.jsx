import { useParams, Link } from 'react-router-dom'
import { GAME_REGISTRY } from '../games/index.js'

/**
 * GamePage — wrapper genérico que carrega o componente do jogo
 * baseado na rota /games/:gameId.
 * Para adicionar um novo jogo, registre-o em src/games/index.js.
 */
export default function GamePage() {
  const { gameId } = useParams()
  const game = GAME_REGISTRY.find(g => g.id === gameId)

  if (!game) {
    return (
      <div style={{ padding: '2rem', textAlign: 'center' }}>
        <p>Jogo não encontrado.</p>
        <Link to="/">← Voltar</Link>
      </div>
    )
  }

  const GameComponent = game.component

  return (
    <main style={{ minHeight: '100vh', padding: '1rem' }}>
      <Link
        to="/"
        style={{ display: 'inline-block', marginBottom: '1rem', color: '#6c63ff', textDecoration: 'none' }}
      >
        ← Voltar
      </Link>
      <GameComponent />
    </main>
  )
}
