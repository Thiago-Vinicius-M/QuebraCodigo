import { useState, useCallback } from 'react'
import { minesweeper } from '../../services/gameService.js'

/**
 * useMinesweeper — hook que encapsula toda a comunicação com a API do Campo Minado.
 */
export function useMinesweeper() {
  const [state, setState]     = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState(null)

  const startGame = useCallback(async (difficulty = 'easy') => {
    setLoading(true)
    setError(null)
    try {
      const res = await minesweeper.start(difficulty)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao iniciar partida.')
    } finally {
      setLoading(false)
    }
  }, [])

  const reveal = useCallback(async (row, col) => {
    if (!state || loading || state.gameOver || state.gameWon) return
    setLoading(true)
    try {
      const res = await minesweeper.reveal(state.gameId, row, col)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao revelar célula.')
    } finally {
      setLoading(false)
    }
  }, [state, loading])

  const flag = useCallback(async (row, col) => {
    if (!state || loading || state.gameOver || state.gameWon) return
    setLoading(true)
    try {
      const res = await minesweeper.flag(state.gameId, row, col)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao marcar bandeira.')
    } finally {
      setLoading(false)
    }
  }, [state, loading])

  const hint = useCallback(async () => {
    if (!state || loading || state.gameOver || state.gameWon) return
    setLoading(true)
    try {
      const res = await minesweeper.hint(state.gameId)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao obter dica.')
    } finally {
      setLoading(false)
    }
  }, [state, loading])

  const restart = useCallback(async (difficulty) => {
    const diff = difficulty ?? state?.difficulty ?? 'easy'
    if (state?.gameId) minesweeper.end(state.gameId).catch(() => {})
    await startGame(diff)
  }, [state, startGame])

  return { state, loading, error, startGame, reveal, flag, hint, restart }
}
