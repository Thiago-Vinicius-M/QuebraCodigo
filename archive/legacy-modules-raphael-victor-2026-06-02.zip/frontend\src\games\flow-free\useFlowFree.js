import { useState, useCallback } from 'react'
import { flowFree } from '../../services/gameService.js'

/**
 * useFlowFree — hook que encapsula a comunicação com a API do Flow Free.
 *
 * Estratégia: o arrasto é gerenciado localmente no componente.
 * Quando o arrasto termina, este hook envia o caminho completo ao servidor.
 */
export function useFlowFree() {
  const [state, setState]     = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState(null)

  const startGame = useCallback(async (level = 1) => {
    setLoading(true)
    setError(null)
    try {
      const res = await flowFree.start(level)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao iniciar partida.')
    } finally {
      setLoading(false)
    }
  }, [])

  const setPath = useCallback(async (color, path) => {
    if (!state || state.gameWon) return
    try {
      const res = await flowFree.setPath(state.gameId, color, path)
      setState(res.data)
    } catch (e) {
      // Silencia erros de validação de caminho (arrasto inválido)
    }
  }, [state])

  const hint = useCallback(async () => {
    if (!state || loading || state.gameWon || state.hintsRemaining <= 0) return
    setLoading(true)
    try {
      const res = await flowFree.hint(state.gameId)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao usar dica.')
    } finally {
      setLoading(false)
    }
  }, [state, loading])

  const restart = useCallback(async () => {
    if (!state) return
    setLoading(true)
    try {
      const res = await flowFree.restart(state.gameId)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao reiniciar.')
    } finally {
      setLoading(false)
    }
  }, [state])

  const goToLevel = useCallback(async (level) => {
    if (!state) return
    setLoading(true)
    try {
      const res = await flowFree.goToLevel(state.gameId, level)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao mudar nível.')
    } finally {
      setLoading(false)
    }
  }, [state])

  return { state, loading, error, startGame, setPath, hint, restart, goToLevel }
}
