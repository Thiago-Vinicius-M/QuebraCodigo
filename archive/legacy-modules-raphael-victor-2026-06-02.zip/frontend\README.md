# Quebra Código — Frontend React

Projeto React + Vite responsável pela interface dos **jogos** do Quebra Código.  
A lógica de cada jogo roda no backend Java (Spring Boot); este frontend só renderiza o estado e envia as ações do usuário.

---

## Pré-requisitos

- Node.js ≥ 18
- Spring Boot rodando em `http://localhost:8150` (necessário para login e API de jogos)

---

## Comandos

```bash
# Instalar dependências (só na primeira vez)
npm install

# Rodar em desenvolvimento (porta 5173, com proxy para Spring)
npm run dev

# Gerar build de produção (sai em ../app/src/main/resources/static/react)
npm run build
```

---

## Estrutura de pastas

```
src/
├── context/
│   └── AuthContext.jsx       # Estado global de autenticação (useAuth)
├── router/
│   └── AppRouter.jsx         # Rotas da aplicação (react-router-dom)
├── services/
│   ├── api.js                # Configuração do axios (proxy, interceptors)
│   └── gameService.js        # Funções de chamada à API de cada jogo
├── pages/
│   ├── Home.jsx              # Tela inicial com lista de jogos
│   └── GamePage.jsx          # Wrapper genérico que carrega qualquer jogo
├── games/
│   ├── index.js              # ← REGISTRO CENTRAL DE JOGOS (leia abaixo)
│   └── connect4/
│       ├── Connect4.jsx      # Componente raiz do Connect 4
│       ├── Connect4Board.jsx # Tabuleiro e animações (Framer Motion)
│       ├── useConnect4.js    # Hook: comunica com o backend
│       └── connect4.module.css
├── App.jsx
└── main.jsx
```

---

## Como adicionar um novo jogo

### 1 — Backend (Java)
Crie em `app/src/main/java/br/com/user/game/{nome}/`:
- `{Nome}State.java`      → estado serializado como JSON
- `{Nome}Service.java`    → toda a lógica de regras
- `{Nome}Controller.java` → endpoints REST em `/api/games/{nome}/`

Endpoints mínimos esperados:
| Método | Rota | Descrição |
|--------|------|-----------|
| POST | `/api/games/{nome}/start` | Nova partida → retorna estado |
| POST | `/api/games/{nome}/{id}/move` | Jogada → retorna estado |
| GET  | `/api/games/{nome}/{id}/state` | Estado atual |
| DELETE | `/api/games/{nome}/{id}` | Encerra partida |

### 2 — Frontend (React)

**a) Crie a pasta do jogo:**
```
src/games/{nome}/
├── {Nome}.jsx          # Componente principal
├── use{Nome}.js        # Hook que chama a API
└── {nome}.module.css
```

**b) Adicione as chamadas de API em `src/services/gameService.js`:**
```js
export const meuJogo = {
  start:    ()            => gameApi.post('/games/meu-jogo/start'),
  move:     (id, dados)   => gameApi.post(`/games/meu-jogo/${id}/move`, dados),
  getState: (id)          => gameApi.get(`/games/meu-jogo/${id}/state`),
  end:      (id)          => gameApi.delete(`/games/meu-jogo/${id}`),
}
```

**c) Registre em `src/games/index.js`:**
```js
import MeuJogo from './meu-jogo/MeuJogo.jsx'

export const GAME_REGISTRY = [
  // ... jogos existentes ...
  { id: 'meu-jogo', name: 'Meu Jogo', icon: '🎮', component: MeuJogo },
]
```

Pronto! O novo jogo aparece automaticamente na Home e ganha sua rota `/games/meu-jogo`.

---

## Tecnologias

| Lib | Uso |
|-----|-----|
| React 18 | UI |
| Vite 5 | Bundler + dev server |
| react-router-dom 6 | Roteamento SPA |
| axios | Chamadas HTTP |
| framer-motion | Animações |

---

## Variáveis de ambiente (opcional)

Crie um arquivo `.env.local` para sobrescrever a URL do backend em produção:

```
VITE_API_BASE_URL=https://meu-servidor.com
```

> Por padrão em desenvolvimento o Vite proxy redireciona `/api` e `/auth` para `localhost:8150`.
