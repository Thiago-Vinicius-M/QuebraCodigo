import { useState, useCallback } from 'react'
import { memory } from '../../services/gameService.js'

/**
 * useMemory — hook que encapsula toda a comunicação com a API do Jogo da Memória.
 * Gerencia o fluxo de duas cartas: vira a 1ª, vira a 2ª, aguarda animação,
 * depois chama reset-pending se não houve par.
 */
export function useMemory() {
  const [state, setState]     = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState(null)

  const startGame = useCallback(async (cols = 4, rows = 4) => {
    setLoading(true)
    setError(null)
    try {
      const res = await memory.start(cols, rows)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao iniciar partida.')
    } finally {
      setLoading(false)
    }
  }, [])

  const flip = useCallback(async (index) => {
    if (!state || loading || state.gameOver || state.pendingReset) return

    const card = state.cards[index]
    if (!card || card.flipped || card.matched) return

    setLoading(true)
    try {
      const res = await memory.flip(state.gameId, index)
      const newState = res.data
      setState(newState)

      // Se duas cartas foram viradas sem par, aguarda a animação e reverte
      if (newState.pendingReset) {
        setTimeout(async () => {
          try {
            const resetRes = await memory.resetPending(newState.gameId)
            setState(resetRes.data)
          } catch {
            // ignora erros no reset silencioso
          } finally {
            setLoading(false)
          }
        }, 700)
      } else {
        setLoading(false)
      }
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao virar carta.')
      setLoading(false)
    }
  }, [state, loading])

  const restart = useCallback(async (cols, rows) => {
    if (state?.gameId) {
      memory.end(state.gameId).catch(() => {})
    }
    await startGame(cols, rows)
  }, [state, startGame])

  return { state, loading, error, startGame, flip, restart }
}
