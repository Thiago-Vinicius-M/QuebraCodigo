import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],

  server: {
    port: 5173,
    proxy: {
      // Repassa chamadas /api/* e /auth/* para o Spring Boot
      '/api': {
        target: 'http://localhost:8150',
        changeOrigin: true,
        secure: false,
      },
      '/auth': {
        target: 'http://localhost:8150',
        changeOrigin: true,
        secure: false,
      },
    },
  },

  build: {
    // Saída vai para dentro do Spring Boot para ser servida em produção
    outDir: '../app/src/main/resources/static/react',
    emptyOutDir: true,
  },
})
