import { useState, useCallback } from 'react'
import { game2048 } from '../../services/gameService.js'

/**
 * use2048 — hook que encapsula toda a comunicação com a API do 2048.
 * O componente Game2048.jsx só chama funções deste hook; nunca acessa a API diretamente.
 */
export function use2048() {
  const [state, setState]     = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState(null)

  const startGame = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await game2048.start()
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao iniciar partida.')
    } finally {
      setLoading(false)
    }
  }, [])

  const move = useCallback(async (direction) => {
    if (!state || loading || state.gameOver) return
    setLoading(true)
    setError(null)
    try {
      const res = await game2048.move(state.gameId, direction)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Movimento inválido.')
    } finally {
      setLoading(false)
    }
  }, [state, loading])

  const undo = useCallback(async () => {
    if (!state || loading || !state.canUndo) return
    setLoading(true)
    setError(null)
    try {
      const res = await game2048.undo(state.gameId)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao desfazer.')
    } finally {
      setLoading(false)
    }
  }, [state, loading])

  const restart = useCallback(async () => {
    if (state?.gameId) {
      game2048.end(state.gameId).catch(() => {})
    }
    await startGame()
  }, [state, startGame])

  return { state, loading, error, startGame, move, undo, restart }
}
