import Connect4 from './connect4/Connect4.jsx'
import Game2048 from './2048/Game2048.jsx'
import Memory from './memory/Memory.jsx'
import Sudoku from './sudoku/Sudoku.jsx'
import Minesweeper from './minesweeper/Minesweeper.jsx'
import FlowFree from './flow-free/FlowFree.jsx'

/**
 * GAME_REGISTRY — lista de todos os jogos disponíveis.
 *
 * Para ADICIONAR um novo jogo:
 *   1. Crie a pasta src/games/{nome}/
 *   2. Implemente o componente principal e o hook useNomeDoJogo
 *   3. Adicione o endpoint no Spring: /api/games/{nome}
 *   4. Registre aqui com { id, name, icon, component }
 */
export const GAME_REGISTRY = [
  {
    id: 'connect4',
    name: 'Connect 4',
    icon: '🔴',
    component: Connect4,
  },
  {
    id: '2048',
    name: '2048',
    icon: '🟩',
    component: Game2048,
  },
  {
    id: 'memory',
    name: 'Memória',
    icon: '🃏',
    component: Memory,
  },
  {
    id: 'sudoku',
    name: 'Sudoku',
    icon: '🔢',
    component: Sudoku,
  },
  {
    id: 'minesweeper',
    name: 'Campo Minado',
    icon: '💣',
    component: Minesweeper,
  },
  {
    id: 'flow-free',
    name: 'Flow Free',
    icon: '🌊',
    component: FlowFree,
  },
  // Próximos jogos — descomente e implemente ao migrar:
  // { id: 'sudoku',      name: 'Sudoku',       icon: '🔢', component: Sudoku },
  // { id: 'minesweeper', name: 'Campo Minado', icon: '💣', component: Minesweeper },
  // { id: 'flow-free',   name: 'Flow Free',    icon: '🌊', component: FlowFree },
]
