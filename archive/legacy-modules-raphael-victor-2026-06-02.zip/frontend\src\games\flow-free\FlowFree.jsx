import { useEffect } from 'react'
import { useFlowFree } from './useFlowFree.js'
import { FlowFreeBoard } from './FlowFreeBoard.jsx'

/**
 * FlowFree — componente raiz do Flow Free.
 * Inicia a partida no nível 1 ao montar.
 */
export default function FlowFree() {
  const { state, loading, error, startGame, setPath, hint, restart, goToLevel } = useFlowFree()

  useEffect(() => {
    startGame(1)
  }, [startGame])

  if (loading && !state) {
    return <p style={{ color: '#8899bb', textAlign: 'center' }}>Carregando…</p>
  }

  if (error && !state) {
    return (
      <div style={{ textAlign: 'center', color: '#ff6b6b' }}>
        <p>{error}</p>
        <button onClick={() => startGame(1)} style={{ marginTop: 12, cursor: 'pointer' }}>
          Tentar novamente
        </button>
      </div>
    )
  }

  return (
    <FlowFreeBoard
      state={state}
      onSetPath={setPath}
      onHint={hint}
      onRestart={restart}
      onGoToLevel={goToLevel}
    />
  )
}
