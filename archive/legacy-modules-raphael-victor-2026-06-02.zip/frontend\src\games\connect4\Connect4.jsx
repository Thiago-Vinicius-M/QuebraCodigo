import { useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useConnect4 } from './useConnect4.js'
import Connect4Board from './Connect4Board.jsx'
import styles from './connect4.module.css'

const PLAYER_LABELS = { RED: '🔴 Vermelho', YELLOW: '🟡 Amarelo' }

/**
 * Connect4 — componente principal do jogo.
 * Toda lógica de regras fica no backend (Java); este componente
 * só renderiza o estado recebido e dispara ações via useConnect4.
 */
export default function Connect4() {
  const { state, loading, error, startGame, makeMove, resetGame } = useConnect4()

  // Inicia partida ao montar
  useEffect(() => { startGame() }, [startGame])

  function statusMessage() {
    if (!state) return 'Iniciando...'
    if (state.gameOver) {
      if (state.winner === 'DRAW') return '🤝 Empate!'
      return `${PLAYER_LABELS[state.winner]} venceu! 🎉`
    }
    return `Vez de: ${PLAYER_LABELS[state.currentPlayer]}`
  }

  return (
    <div className={styles.wrapper}>
      <h1 className={styles.title}>Connect 4</h1>

      <AnimatePresence mode="wait">
        <motion.p
          key={statusMessage()}
          className={styles.status}
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
        >
          {statusMessage()}
        </motion.p>
      </AnimatePresence>

      {state && (
        <Connect4Board
          board={state.board}
          onColumnClick={makeMove}
          gameOver={state.gameOver}
        />
      )}

      {error && <p className={styles.error}>{error}</p>}

      <div className={styles.actions}>
        <button
          className={`${styles.btn} ${styles.btnPrimary}`}
          onClick={resetGame}
          disabled={loading}
        >
          {loading ? 'Aguarde...' : 'Nova partida'}
        </button>
      </div>
    </div>
  )
}
