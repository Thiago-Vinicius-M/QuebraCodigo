import { useState, useRef, useCallback, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import css from './flowfree.module.css'

/** Cores das 6 possíveis cores de fluxo (mesma ordem do backend) */
const COLORS = [
  '',           // índice 0 = vazio
  '#e74c3c',    // 1 = Vermelho
  '#3498db',    // 2 = Azul
  '#2ecc71',    // 3 = Verde
  '#f1c40f',    // 4 = Amarelo
  '#e67e22',    // 5 = Laranja
  '#9b59b6',    // 6 = Roxo
]

/**
 * FlowFreeBoard — renderiza o grid e gerencia o arrasto de caminhos.
 *
 * Estratégia de arrasto:
 *  - O caminho atual é mantido em estado local (sem chamada à API durante o drag).
 *  - Ao soltar, o caminho é enviado ao servidor via onSetPath.
 *  - O grid exibido = grid do servidor + sobreposição do caminho em andamento.
 */
export function FlowFreeBoard({ state, onSetPath, onHint, onRestart, onGoToLevel }) {
  const [drawingColor, setDrawingColor]   = useState(null)
  const [drawingFrom,  setDrawingFrom]    = useState(null)  // 0 ou 1 (índice do endpoint)
  const [currentPath,  setCurrentPath]    = useState([])    // [[r,c], ...]
  const gridRef  = useRef(null)
  const dragging = useRef(false)

  if (!state) return null

  const { grid, size, endpoints, numColors, hintsRemaining, levelIndex, totalLevels, gameWon, message } = state

  /* ─── Grid de exibição (servidor + drag local) ───────────────────────────── */
  const displayGrid = [...grid]
  if (drawingColor !== null) {
    for (const [r, c] of currentPath) {
      displayGrid[r * size + c] = drawingColor
    }
  }

  /* ─── Helpers ────────────────────────────────────────────────────────────── */
  function isEndpoint(r, c) {
    for (let ci = 0; ci < numColors; ci++) {
      const eps = endpoints[ci]
      if ((eps[0][0] === r && eps[0][1] === c) || (eps[1][0] === r && eps[1][1] === c))
        return ci + 1  // color (1-based)
    }
    return 0
  }

  function getEndpointsForColor(color) {
    return endpoints[color - 1]
  }

  function indexInPath(path, r, c) {
    return path.findIndex(([pr, pc]) => pr === r && pc === c)
  }

  function isAdjacent([r1, c1], [r2, c2]) {
    return Math.abs(r1 - r2) + Math.abs(c1 - c2) === 1
  }

  /* ─── Início do arrasto ──────────────────────────────────────────────────── */
  function startDraw(r, c) {
    const color = displayGrid[r * size + c]
    if (!color) return

    const eps      = getEndpointsForColor(color)
    const epIdx    = eps.findIndex(([er, ec]) => er === r && ec === c)
    if (epIdx < 0) {
      // Clicou numa célula do caminho — recomeça do endpoint mais próximo
      // Por simplicidade, começa do endpoint 0
      const [er, ec] = eps[0]
      dragging.current = true
      setDrawingColor(color)
      setDrawingFrom(0)
      setCurrentPath([[er, ec]])
      return
    }

    dragging.current = true
    setDrawingColor(color)
    setDrawingFrom(epIdx)
    setCurrentPath([[r, c]])
  }

  /* ─── Extensão do arrasto ────────────────────────────────────────────────── */
  function extendDraw(r, c) {
    if (!dragging.current || drawingColor === null) return

    setCurrentPath(prev => {
      if (prev.length === 0) return prev

      const last = prev[prev.length - 1]
      if (!isAdjacent(last, [r, c])) return prev

      // Chegou no endpoint oposto → fecha conexão
      const eps      = getEndpointsForColor(drawingColor)
      const otherEp  = eps[1 - drawingFrom]
      if (r === otherEp[0] && c === otherEp[1]) {
        const newPath = [...prev, [r, c]]
        // Envia ao servidor e encerra arrasto
        onSetPath(drawingColor, newPath)
        dragging.current = false
        setDrawingColor(null)
        setCurrentPath([])
        return []
      }

      // Retrocede no caminho se entrou numa célula já visitada
      const idx = indexInPath(prev, r, c)
      if (idx >= 0) return prev.slice(0, idx + 1)

      // Só avança em células vazias (no grid do servidor)
      const serverVal = grid[r * size + c]
      if (serverVal !== 0 && serverVal !== drawingColor) return prev

      return [...prev, [r, c]]
    })
  }

  /* ─── Fim do arrasto ─────────────────────────────────────────────────────── */
  const stopDraw = useCallback(() => {
    if (!dragging.current) return
    dragging.current = false

    setCurrentPath(prev => {
      if (prev.length > 0 && drawingColor !== null) {
        onSetPath(drawingColor, prev)
      }
      return []
    })
    setDrawingColor(null)
  }, [drawingColor, onSetPath])

  /* ─── Pointer events no grid ─────────────────────────────────────────────── */
  function cellFromEvent(e) {
    const el = document.elementFromPoint(e.clientX, e.clientY)
    if (!el || !el.dataset.row) return null
    return [parseInt(el.dataset.row), parseInt(el.dataset.col)]
  }

  function handlePointerDown(e) {
    e.preventDefault()
    const cell = cellFromEvent(e)
    if (cell) startDraw(cell[0], cell[1])
  }

  function handlePointerMove(e) {
    if (!dragging.current) return
    const cell = cellFromEvent(e)
    if (cell) extendDraw(cell[0], cell[1])
  }

  useEffect(() => {
    window.addEventListener('pointerup', stopDraw)
    return () => window.removeEventListener('pointerup', stopDraw)
  }, [stopDraw])

  /* ─── Render ─────────────────────────────────────────────────────────────── */
  const cellPx = size <= 5 ? 'clamp(44px,10vw,64px)' : 'clamp(36px,8vw,54px)'

  return (
    <div className={css.wrapper}>
      {/* Info */}
      <div className={css.infoRow}>
        <div className={css.infoPanel}>
          <span className={css.infoLabel}>Nível</span>
          <span className={css.infoValue}>{levelIndex + 1}/{totalLevels}</span>
        </div>
        <div className={css.infoPanel}>
          <span className={css.infoLabel}>💡 Dicas</span>
          <span className={css.infoValue}>{hintsRemaining}</span>
        </div>
      </div>

      {/* Controles */}
      <div className={css.controls}>
        <button className={css.btn} disabled={levelIndex <= 0} onClick={() => onGoToLevel(levelIndex)}>
          ← Anterior
        </button>
        <button className={css.btn} disabled={levelIndex >= totalLevels - 1} onClick={() => onGoToLevel(levelIndex + 2)}>
          Próximo →
        </button>
        <button className={css.btn} onClick={onRestart}>⟳ Reiniciar</button>
        <button className={css.btn} disabled={hintsRemaining <= 0} onClick={onHint}>
          💡 Dica ({hintsRemaining})
        </button>
      </div>

      {/* Grid */}
      <div className={css.boardWrapper}>
        <div
          ref={gridRef}
          className={css.grid}
          style={{ gridTemplateColumns: `repeat(${size}, ${cellPx})`, touchAction: 'none' }}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
        >
          {displayGrid.map((colorVal, idx) => {
            const r   = Math.floor(idx / size)
            const c   = idx % size
            const ep  = isEndpoint(r, c)
            const bg  = COLORS[colorVal] ?? ''
            const isInCurrentPath = drawingColor !== null && currentPath.some(([pr, pc]) => pr === r && pc === c)
            return (
              <div
                key={idx}
                data-row={r}
                data-col={c}
                className={`${css.cell} ${ep ? css.endpoint : ''} ${isInCurrentPath ? css.inPath : ''}`}
                style={{
                  width: cellPx, height: cellPx,
                  backgroundColor: colorVal ? bg : undefined,
                  boxShadow: ep && colorVal ? `0 0 0 3px ${bg}, 0 0 12px ${bg}88` : undefined,
                }}
              />
            )
          })}
        </div>

        {/* Overlay de vitória */}
        <AnimatePresence>
          {gameWon && (
            <motion.div
              className={css.overlay}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <div className={css.overlayTitle}>Nível Completo! 🎉</div>
              <div className={css.overlayText}>{message}</div>
              {levelIndex < totalLevels - 1
                ? <button className={css.btn} onClick={() => onGoToLevel(levelIndex + 2)}>Próximo Nível →</button>
                : <button className={css.btn} onClick={onRestart}>Jogar Novamente</button>
              }
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Status */}
      {!gameWon && <p className={css.statusMsg}>{message}</p>}

      {/* Instruções */}
      <div className={css.instructions}>
        <span>Arraste para conectar pontos da mesma cor</span>
        <span>·</span>
        <span>Preencha todas as células para vencer</span>
      </div>
    </div>
  )
}
