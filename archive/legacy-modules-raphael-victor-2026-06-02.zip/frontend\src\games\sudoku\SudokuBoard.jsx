import { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import css from './sudoku.module.css'

/**
 * SudokuBoard — renderiza o tabuleiro 9×9 e os controles.
 *
 * Props:
 *   state      — estado retornado pelo backend
 *   onPlace    — fn(index, value)
 *   onErase    — fn(index)
 *   onSolve    — fn()
 *   onClear    — fn()
 *   onRestart  — fn(difficulty)
 */
export function SudokuBoard({ state, onPlace, onErase, onSolve, onClear, onRestart }) {
  const [selected, setSelected] = useState(-1)

  if (!state) return null

  const { board, given, conflicts, correct, difficulty, gameOver, message } = state

  /* ─── Helpers de destaque ─────────────────────────────────────────────── */
  function isHighlighted(idx) {
    if (selected < 0) return false
    const selRow = Math.floor(selected / 9), selCol = selected % 9
    const row    = Math.floor(idx / 9),      col    = idx % 9
    const sameBlock =
      Math.floor(row / 3) === Math.floor(selRow / 3) &&
      Math.floor(col / 3) === Math.floor(selCol / 3)
    return row === selRow || col === selCol || sameBlock
  }

  /* ─── Clique numa célula ──────────────────────────────────────────────── */
  function handleCellClick(idx) {
    if (given[idx]) { setSelected(idx); return }
    setSelected(idx)
  }

  /* ─── Teclado: número ou Delete/Backspace ────────────────────────────── */
  function handleKeyDown(e) {
    if (selected < 0 || given[selected]) return
    const num = parseInt(e.key)
    if (num >= 1 && num <= 9) {
      onPlace(selected, num)
    } else if (e.key === 'Backspace' || e.key === 'Delete' || e.key === '0') {
      onErase(selected)
    }
  }

  /* ─── Pad numérico (mobile) ──────────────────────────────────────────── */
  function handlePad(num) {
    if (selected < 0 || given[selected]) return
    if (num === 0) onErase(selected)
    else onPlace(selected, num)
  }

  /* ─── Classe CSS de cada célula ──────────────────────────────────────── */
  function cellClass(idx) {
    const classes = [css.cell]
    if (given[idx])      classes.push(css.cellGiven)
    if (conflicts[idx])  classes.push(css.cellConflict)
    else if (correct[idx]) classes.push(css.cellCorrect)
    if (idx === selected) classes.push(css.cellActive)
    else if (isHighlighted(idx)) classes.push(css.cellHighlight)
    return classes.join(' ')
  }

  const difficulties = ['easy', 'medium', 'hard']
  const diffLabel    = { easy: 'Fácil', medium: 'Médio', hard: 'Difícil' }

  return (
    <div className={css.wrapper} onKeyDown={handleKeyDown} tabIndex={0}>
      {/* Seletor de dificuldade */}
      <div className={css.controls}>
        {difficulties.map(d => (
          <button
            key={d}
            className={`${css.btn} ${difficulty === d ? css.btnActive : ''}`}
            onClick={() => onRestart(d)}
          >
            {diffLabel[d]}
          </button>
        ))}
        <button className={css.btn} onClick={() => onRestart(difficulty)}>⟳ Novo</button>
        <button className={css.btn} onClick={onSolve}>💡 Resolver</button>
        <button className={css.btn} onClick={onClear}>✕ Limpar</button>
      </div>

      {/* Tabuleiro */}
      <div className={css.boardWrapper}>
        <div className={css.grid}>
          {board.map((val, idx) => (
            <div
              key={idx}
              className={cellClass(idx)}
              onClick={() => handleCellClick(idx)}
              style={{
                borderRightWidth:  (idx % 9) % 3 === 2 && idx % 9 !== 8 ? '2px' : undefined,
                borderBottomWidth: (Math.floor(idx / 9)) % 3 === 2 && Math.floor(idx / 9) !== 8 ? '2px' : undefined,
              }}
            >
              {val !== 0 ? val : ''}
            </div>
          ))}
        </div>

        {/* Overlay de vitória */}
        <AnimatePresence>
          {gameOver && (
            <motion.div
              className={css.overlay}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <div className={css.overlayTitle}>Parabéns! 🏆</div>
              <div className={css.overlayText}>{message}</div>
              <button className={css.btn} onClick={() => onRestart(difficulty)}>
                Novo Jogo
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Pad numérico */}
      <div className={css.numpad}>
        {[1,2,3,4,5,6,7,8,9].map(n => (
          <button key={n} className={css.padBtn} onClick={() => handlePad(n)}>{n}</button>
        ))}
        <button className={css.padBtn} onClick={() => handlePad(0)}>✕</button>
      </div>

      {/* Mensagem de status */}
      {!gameOver && <p className={css.statusMsg}>{message}</p>}
    </div>
  )
}
