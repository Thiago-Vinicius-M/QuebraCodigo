import { useEffect } from 'react'
import { useMemory } from './useMemory.js'
import { MemoryBoard } from './MemoryBoard.jsx'

/**
 * Memory — componente raiz do Jogo da Memória.
 *
 * Responsabilidades:
 *  - Inicia a partida ao montar
 *  - Encaminha ações (flip, restart) para o hook useMemory
 *  - Passa o estado para MemoryBoard renderizar
 */
export default function Memory() {
  const { state, loading, error, startGame, flip, restart } = useMemory()

  useEffect(() => {
    startGame(4, 4)
  }, [startGame])

  if (loading && !state) {
    return <p style={{ color: '#8899bb', textAlign: 'center' }}>Carregando…</p>
  }

  if (error && !state) {
    return (
      <div style={{ textAlign: 'center', color: '#ff6b6b' }}>
        <p>{error}</p>
        <button onClick={() => startGame(4, 4)} style={{ marginTop: 12, cursor: 'pointer' }}>
          Tentar novamente
        </button>
      </div>
    )
  }

  return (
    <MemoryBoard
      state={state}
      onFlip={flip}
      onRestart={restart}
    />
  )
}
