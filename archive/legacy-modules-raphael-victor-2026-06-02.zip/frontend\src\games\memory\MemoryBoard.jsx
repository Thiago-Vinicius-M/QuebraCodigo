import { motion, AnimatePresence } from 'framer-motion'
import css from './memory.module.css'

/**
 * MemoryBoard — renderiza o grid de cartas com animação de flip 3D.
 *
 * Props:
 *   state     — estado retornado pelo backend
 *   onFlip    — fn(index) chamada quando o jogador clica numa carta
 *   onRestart — fn(cols, rows) chamada ao reiniciar
 */
export function MemoryBoard({ state, onFlip, onRestart }) {
  if (!state) return null

  const { cards, cols, moves, matchedPairs, totalPairs, gameOver, message } = state

  const sizeOptions = [
    { label: '4 × 4', cols: 4, rows: 4 },
    { label: '5 × 4', cols: 5, rows: 4 },
    { label: '6 × 4', cols: 6, rows: 4 },
  ]

  return (
    <div className={css.wrapper}>
      {/* Cabeçalho com placar */}
      <div className={css.header}>
        <div className={css.scoreBox}>
          <span className={css.scoreLabel}>Movimentos</span>
          <span className={css.scoreValue}>{moves}</span>
        </div>
        <div className={css.scoreBox}>
          <span className={css.scoreLabel}>Pares</span>
          <span className={css.scoreValue}>{matchedPairs}/{totalPairs}</span>
        </div>
      </div>

      {/* Seletor de tamanho + botão reiniciar */}
      <div className={css.controls}>
        {sizeOptions.map(opt => (
          <button
            key={opt.label}
            className={`${css.btn} ${cols === opt.cols ? css.btnActive : ''}`}
            onClick={() => onRestart(opt.cols, opt.rows)}
          >
            {opt.label}
          </button>
        ))}
        <button className={css.btn} onClick={() => onRestart(cols, 4)}>
          ⟳ Novo jogo
        </button>
      </div>

      {/* Grid de cartas */}
      <div className={css.boardWrapper}>
        <div
          className={css.grid}
          style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}
        >
          {cards.map((card) => (
            <div
              key={card.index}
              className={`${css.cardScene} ${card.flipped || card.matched ? css.flipped : ''} ${card.matched ? css.matched : ''}`}
              onClick={() => onFlip(card.index)}
            >
              <div className={css.card}>
                <div className={css.cardFront} />
                <div className={css.cardBack}>
                  <img
                    src={`/games/img/cartas/${card.pairValue}.png`}
                    alt={`carta ${card.pairValue}`}
                    className={css.cardImage}
                    draggable={false}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Overlay de vitória */}
        <AnimatePresence>
          {gameOver && (
            <motion.div
              className={css.overlay}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <div className={css.overlayTitle}>Parabéns! 🎉</div>
              <div className={css.overlayText}>{message}</div>
              <button className={css.btn} onClick={() => onRestart(cols, 4)}>
                Jogar Novamente
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Mensagem de status */}
      {!gameOver && (
        <p className={css.statusMsg}>{message}</p>
      )}
    </div>
  )
}
