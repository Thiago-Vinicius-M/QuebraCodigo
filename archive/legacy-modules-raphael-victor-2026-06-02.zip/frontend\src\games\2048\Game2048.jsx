import { useEffect, useCallback, useRef } from 'react'
import { use2048 } from './use2048.js'
import { Game2048Board } from './Game2048Board.jsx'

/**
 * Game2048 — componente raiz do 2048.
 *
 * Responsabilidades:
 *  - Inicia a partida ao montar
 *  - Ouve teclado (↑↓←→) e swipe touch
 *  - Encaminha ações para o hook use2048
 *  - Passa o estado para Game2048Board renderizar
 */
export default function Game2048() {
  const { state, loading, error, startGame, move, undo, restart } = use2048()
  const boardRef = useRef(null)

  useEffect(() => {
    startGame()
  }, [startGame])

  const handleKey = useCallback((e) => {
    const map = {
      ArrowUp: 'UP', ArrowDown: 'DOWN',
      ArrowLeft: 'LEFT', ArrowRight: 'RIGHT',
    }
    const dir = map[e.key]
    if (dir) {
      e.preventDefault()
      move(dir)
    }
  }, [move])

  useEffect(() => {
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [handleKey])

  const touch = useRef({ x: 0, y: 0 })
  const handleTouchStart = useCallback((e) => {
    touch.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }
  }, [])
  const handleTouchEnd = useCallback((e) => {
    const dx = e.changedTouches[0].clientX - touch.current.x
    const dy = e.changedTouches[0].clientY - touch.current.y
    if (Math.abs(dx) < 20 && Math.abs(dy) < 20) return
    if (Math.abs(dx) > Math.abs(dy)) {
      move(dx > 0 ? 'RIGHT' : 'LEFT')
    } else {
      move(dy > 0 ? 'DOWN' : 'UP')
    }
  }, [move])

  if (loading && !state) {
    return <p style={{ color: '#8899bb', textAlign: 'center' }}>Carregando…</p>
  }

  if (error && !state) {
    return (
      <div style={{ textAlign: 'center', color: '#ff6b6b' }}>
        <p>{error}</p>
        <button onClick={startGame} style={{ marginTop: 12, cursor: 'pointer' }}>
          Tentar novamente
        </button>
      </div>
    )
  }

  return (
    <div
      ref={boardRef}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      style={{ outline: 'none', width: '100%' }}
      tabIndex={-1}
    >
      <Game2048Board
        state={state}
        onMove={move}
        onUndo={undo}
        onRestart={restart}
      />
    </div>
  )
}
