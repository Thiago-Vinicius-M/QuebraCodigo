import { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import css from './minesweeper.module.css'

/** Cores clássicas dos números de adjacência */
const NUM_COLORS = ['', '#4a9eff', '#4caf50', '#f44336', '#1a237e', '#b71c1c', '#00838f', '#212121', '#9e9e9e']

/**
 * MinesweeperBoard — renderiza o campo minado.
 *
 * Props:
 *   state      — estado retornado pelo backend
 *   onReveal   — fn(row, col)
 *   onFlag     — fn(row, col)
 *   onHint     — fn()
 *   onRestart  — fn(difficulty?)
 */
export function MinesweeperBoard({ state, onReveal, onFlag, onHint, onRestart }) {
  /** Modo bandeira: quando ativo, clique esquerdo coloca bandeira (útil no mobile) */
  const [flagMode, setFlagMode] = useState(false)

  if (!state) return null

  const { cells, rows, cols, totalMines, flagCount, difficulty, gameOver, gameWon, message } = state
  const minesLeft = totalMines - flagCount

  const difficulties = ['easy', 'medium', 'hard']
  const diffLabel    = { easy: 'Fácil (8×8)', medium: 'Médio (14×14)', hard: 'Difícil (20×20)' }

  /* ─── Clique esquerdo ────────────────────────────────────────────────────── */
  const handleClick = useCallback((row, col, cell) => {
    if (gameOver || gameWon) return
    if (cell.revealed) return
    if (flagMode) {
      onFlag(row, col)
    } else {
      if (!cell.flagged) onReveal(row, col)
    }
  }, [gameOver, gameWon, flagMode, onReveal, onFlag])

  /* ─── Clique direito (bandeira) ──────────────────────────────────────────── */
  const handleContextMenu = useCallback((e, row, col) => {
    e.preventDefault()
    if (gameOver || gameWon) return
    onFlag(row, col)
  }, [gameOver, gameWon, onFlag])

  /* ─── Conteúdo de uma célula ─────────────────────────────────────────────── */
  function cellContent(cell) {
    if (!cell.revealed) return cell.flagged ? '🚩' : ''
    if (cell.mine)      return cell.exploded ? '💥' : '💣'
    return cell.adjacentMines > 0 ? cell.adjacentMines : ''
  }

  function cellStyle(cell) {
    if (cell.revealed && !cell.mine && cell.adjacentMines > 0) {
      return { color: NUM_COLORS[cell.adjacentMines] }
    }
    return {}
  }

  function cellClass(cell) {
    const cls = [css.cell]
    if (cell.revealed)  cls.push(css.revealed)
    if (cell.exploded)  cls.push(css.exploded)
    if (cell.mine && cell.revealed && !cell.exploded) cls.push(css.mine)
    if (cell.flagged && !cell.revealed) cls.push(css.flagged)
    return cls.join(' ')
  }

  /* ─── Tamanho dinâmico da célula conforme dificuldade ────────────────────── */
  const cellSize = difficulty === 'hard' ? 'clamp(18px,4vw,30px)'
                 : difficulty === 'medium' ? 'clamp(22px,5vw,36px)'
                 : 'clamp(26px,6vw,44px)'

  return (
    <div className={css.wrapper}>
      {/* Painéis de info */}
      <div className={css.infoRow}>
        <div className={css.infoPanel}>
          <span className={css.infoLabel}>💣 Minas</span>
          <span className={css.infoValue}>{minesLeft}</span>
        </div>
        <div className={css.infoPanel}>
          <span className={css.infoLabel}>🚩 Bandeiras</span>
          <span className={css.infoValue}>{flagCount}</span>
        </div>
      </div>

      {/* Controles */}
      <div className={css.controls}>
        {difficulties.map(d => (
          <button
            key={d}
            className={`${css.btn} ${difficulty === d ? css.btnActive : ''}`}
            onClick={() => onRestart(d)}
          >
            {diffLabel[d]}
          </button>
        ))}
        <button className={css.btn} onClick={() => onRestart(difficulty)}>⟳ Novo</button>
        <button className={css.btn} onClick={onHint}>💡 Dica</button>
        <button
          className={`${css.btn} ${flagMode ? css.btnFlagActive : ''}`}
          onClick={() => setFlagMode(v => !v)}
          title="Modo bandeira (útil no celular)"
        >
          🚩 {flagMode ? 'Bandeira ON' : 'Bandeira OFF'}
        </button>
      </div>

      {/* Campo */}
      <div className={css.boardWrapper}>
        <div
          className={css.grid}
          style={{ gridTemplateColumns: `repeat(${cols}, ${cellSize})` }}
        >
          {cells.map((cell, idx) => {
            const row = Math.floor(idx / cols)
            const col = idx % cols
            return (
              <div
                key={idx}
                className={cellClass(cell)}
                style={{ ...cellStyle(cell), width: cellSize, height: cellSize, fontSize: `calc(${cellSize} * 0.55)` }}
                onClick={() => handleClick(row, col, cell)}
                onContextMenu={(e) => handleContextMenu(e, row, col)}
              >
                {cellContent(cell)}
              </div>
            )
          })}
        </div>

        {/* Overlay de fim de jogo */}
        <AnimatePresence>
          {(gameOver || gameWon) && (
            <motion.div
              className={css.overlay}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <div className={css.overlayTitle}>
                {gameWon ? '🎉 Você Venceu!' : '💥 Game Over!'}
              </div>
              <div className={css.overlayText}>{message}</div>
              <button className={css.btn} onClick={() => onRestart(difficulty)}>
                Jogar Novamente
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Status */}
      {!gameOver && !gameWon && (
        <p className={css.statusMsg}>{message}</p>
      )}

      {/* Instruções */}
      <div className={css.instructions}>
        <span>Clique esquerdo: revelar</span>
        <span>·</span>
        <span>Clique direito: 🚩 bandeira</span>
        <span>·</span>
        <span>No celular: use o botão 🚩</span>
      </div>
    </div>
  )
}
