import { gameApi } from './api.js'

/**
 * gameService — chamadas à API de jogos do Spring Boot.
 * Endpoint base: /api/games/{jogo}
 *
 * Para adicionar um novo jogo, basta criar funções análogas aqui
 * e seguir a mesma estrutura de pasta em src/games/{novoJogo}/.
 */

// ─── Connect 4 ────────────────────────────────────────────────────────────────

export const connect4 = {
  /** Inicia uma nova partida e retorna o estado inicial */
  start: () => gameApi.post('/games/connect4/start'),

  /** Realiza uma jogada na coluna indicada (0-6) */
  move: (gameId, col) => gameApi.post(`/games/connect4/${gameId}/move`, { col }),

  /** Busca o estado atual de uma partida */
  getState: (gameId) => gameApi.get(`/games/connect4/${gameId}/state`),

  /** Encerra / descarta uma partida */
  end: (gameId) => gameApi.delete(`/games/connect4/${gameId}`),
}

// ─── 2048 ─────────────────────────────────────────────────────────────────────

export const game2048 = {
  /** Inicia uma nova partida e retorna o estado inicial */
  start: () => gameApi.post('/games/2048/start'),

  /** Executa um movimento na direção indicada ("UP" | "DOWN" | "LEFT" | "RIGHT") */
  move: (gameId, direction) => gameApi.post(`/games/2048/${gameId}/move`, { direction }),

  /** Desfaz o último movimento */
  undo: (gameId) => gameApi.post(`/games/2048/${gameId}/undo`),

  /** Busca o estado atual de uma partida */
  getState: (gameId) => gameApi.get(`/games/2048/${gameId}/state`),

  /** Encerra / descarta uma partida */
  end: (gameId) => gameApi.delete(`/games/2048/${gameId}`),
}

// ─── Memória ──────────────────────────────────────────────────────────────────

export const memory = {
  /** Inicia nova partida com o tamanho de grid especificado */
  start: (cols = 4, rows = 4) => gameApi.post(`/games/memory/start?cols=${cols}&rows=${rows}`),

  /** Vira a carta no índice informado */
  flip: (gameId, index) => gameApi.post(`/games/memory/${gameId}/flip`, { index }),

  /** Reverte as cartas sem par após animação do frontend */
  resetPending: (gameId) => gameApi.post(`/games/memory/${gameId}/reset-pending`),

  /** Busca o estado atual de uma partida */
  getState: (gameId) => gameApi.get(`/games/memory/${gameId}/state`),

  /** Encerra / descarta uma partida */
  end: (gameId) => gameApi.delete(`/games/memory/${gameId}`),
}

// ─── Flow Free ────────────────────────────────────────────────────────────────

export const flowFree = {
  /** Inicia nova partida no nível indicado (1-based) */
  start: (level = 1) => gameApi.post(`/games/flow-free/start?level=${level}`),

  /** Define o caminho completo de uma cor após o arrasto */
  setPath: (gameId, color, path) => gameApi.post(`/games/flow-free/${gameId}/set-path`, { color, path }),

  /** Usa uma dica */
  hint: (gameId) => gameApi.post(`/games/flow-free/${gameId}/hint`),

  /** Reinicia o nível atual */
  restart: (gameId) => gameApi.post(`/games/flow-free/${gameId}/restart`),

  /** Vai para um nível específico (1-based) */
  goToLevel: (gameId, level) => gameApi.post(`/games/flow-free/${gameId}/level`, { level }),

  /** Busca estado atual */
  getState: (gameId) => gameApi.get(`/games/flow-free/${gameId}/state`),

  /** Encerra a partida */
  end: (gameId) => gameApi.delete(`/games/flow-free/${gameId}`),
}

// ─── Campo Minado ─────────────────────────────────────────────────────────────

export const minesweeper = {
  /** Inicia nova partida ("easy" | "medium" | "hard") */
  start: (difficulty = 'easy') => gameApi.post(`/games/minesweeper/start?difficulty=${difficulty}`),

  /** Revela uma célula */
  reveal: (gameId, row, col) => gameApi.post(`/games/minesweeper/${gameId}/reveal`, { row, col }),

  /** Alterna bandeira em uma célula */
  flag: (gameId, row, col) => gameApi.post(`/games/minesweeper/${gameId}/flag`, { row, col }),

  /** Solicita uma dica (revela célula segura) */
  hint: (gameId) => gameApi.post(`/games/minesweeper/${gameId}/hint`),

  /** Busca estado atual */
  getState: (gameId) => gameApi.get(`/games/minesweeper/${gameId}/state`),

  /** Encerra a partida */
  end: (gameId) => gameApi.delete(`/games/minesweeper/${gameId}`),
}

// ─── Sudoku ───────────────────────────────────────────────────────────────────

export const sudoku = {
  /** Inicia nova partida com a dificuldade especificada ("easy" | "medium" | "hard") */
  start: (difficulty = 'easy') => gameApi.post(`/games/sudoku/start?difficulty=${difficulty}`),

  /** Coloca um número (1-9) em uma célula */
  place: (gameId, index, value) => gameApi.post(`/games/sudoku/${gameId}/place`, { index, value }),

  /** Apaga o valor de uma célula */
  erase: (gameId, index) => gameApi.post(`/games/sudoku/${gameId}/erase`, { index }),

  /** Revela a solução completa */
  solve: (gameId) => gameApi.post(`/games/sudoku/${gameId}/solve`),

  /** Limpa todas as entradas do jogador */
  clear: (gameId) => gameApi.post(`/games/sudoku/${gameId}/clear`),

  /** Busca o estado atual */
  getState: (gameId) => gameApi.get(`/games/sudoku/${gameId}/state`),

  /** Encerra a partida */
  end: (gameId) => gameApi.delete(`/games/sudoku/${gameId}`),
}
