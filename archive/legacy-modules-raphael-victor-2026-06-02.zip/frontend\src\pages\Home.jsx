import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import { GAME_REGISTRY } from '../games/index.js'

export default function Home() {
  const { user, logout } = useAuth()

  return (
    <main style={{ padding: '2rem', maxWidth: '900px', margin: '0 auto' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
        <h1>Bem-vindo, {user?.username}!</h1>
        <button
          onClick={() => { logout(); window.location.href = '/login.html' }}
          style={{ padding: '0.5rem 1rem', borderRadius: '8px', border: 'none', background: '#e74c3c', color: '#fff' }}
        >
          Sair
        </button>
      </header>

      <h2 style={{ marginBottom: '1rem' }}>Jogos</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: '1rem' }}>
        {GAME_REGISTRY.map(game => (
          <Link
            key={game.id}
            to={`/games/${game.id}`}
            style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center',
              padding: '1.5rem 1rem', borderRadius: '12px',
              background: '#1a1a2e', textDecoration: 'none', color: '#e0e0e0',
              border: '1px solid #2a2a4a', transition: 'transform 0.2s',
            }}
          >
            <span style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>{game.icon}</span>
            <span style={{ fontWeight: 600 }}>{game.name}</span>
          </Link>
        ))}
      </div>
    </main>
  )
}
