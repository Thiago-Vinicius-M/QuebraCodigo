# Adicionando um novo jogo

Cada jogo segue a mesma convenção de pasta:

```
src/games/{nome}/
├── {Nome}.jsx          # Componente raiz (montado pelo GamePage)
├── use{Nome}.js        # Hook: toda comunicação com o backend aqui
└── {nome}.module.css   # Estilos isolados (CSS Modules)
```

Depois de criar os arquivos, registre o jogo em `src/games/index.js`.  
Consulte o README principal para o passo a passo completo.
