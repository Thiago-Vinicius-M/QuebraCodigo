import { useEffect } from 'react'
import { useMinesweeper } from './useMinesweeper.js'
import { MinesweeperBoard } from './MinesweeperBoard.jsx'

/**
 * Minesweeper — componente raiz do Campo Minado.
 * Inicia a partida ao montar e delega toda a renderização para MinesweeperBoard.
 */
export default function Minesweeper() {
  const { state, loading, error, startGame, reveal, flag, hint, restart } = useMinesweeper()

  useEffect(() => {
    startGame('easy')
  }, [startGame])

  if (loading && !state) {
    return <p style={{ color: '#8899bb', textAlign: 'center' }}>Carregando…</p>
  }

  if (error && !state) {
    return (
      <div style={{ textAlign: 'center', color: '#ff6b6b' }}>
        <p>{error}</p>
        <button onClick={() => startGame('easy')} style={{ marginTop: 12, cursor: 'pointer' }}>
          Tentar novamente
        </button>
      </div>
    )
  }

  return (
    <MinesweeperBoard
      state={state}
      onReveal={reveal}
      onFlag={flag}
      onHint={hint}
      onRestart={restart}
    />
  )
}
