import { useState, useCallback } from 'react'
import { sudoku } from '../../services/gameService.js'

/**
 * useSudoku — hook que encapsula toda a comunicação com a API do Sudoku.
 */
export function useSudoku() {
  const [state, setState]     = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState(null)

  const startGame = useCallback(async (difficulty = 'easy') => {
    setLoading(true)
    setError(null)
    try {
      const res = await sudoku.start(difficulty)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao iniciar partida.')
    } finally {
      setLoading(false)
    }
  }, [])

  const place = useCallback(async (index, value) => {
    if (!state || loading || state.gameOver) return
    setLoading(true)
    try {
      const res = await sudoku.place(state.gameId, index, value)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Jogada inválida.')
    } finally {
      setLoading(false)
    }
  }, [state, loading])

  const erase = useCallback(async (index) => {
    if (!state || loading || state.gameOver) return
    setLoading(true)
    try {
      const res = await sudoku.erase(state.gameId, index)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao apagar.')
    } finally {
      setLoading(false)
    }
  }, [state, loading])

  const solve = useCallback(async () => {
    if (!state || loading) return
    setLoading(true)
    try {
      const res = await sudoku.solve(state.gameId)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao resolver.')
    } finally {
      setLoading(false)
    }
  }, [state, loading])

  const clear = useCallback(async () => {
    if (!state || loading) return
    setLoading(true)
    try {
      const res = await sudoku.clear(state.gameId)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao limpar.')
    } finally {
      setLoading(false)
    }
  }, [state, loading])

  const restart = useCallback(async (difficulty) => {
    const diff = difficulty ?? state?.difficulty ?? 'easy'
    if (state?.gameId) sudoku.end(state.gameId).catch(() => {})
    await startGame(diff)
  }, [state, startGame])

  return { state, loading, error, startGame, place, erase, solve, clear, restart }
}
