import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import Home from '../pages/Home.jsx'
import GamePage from '../pages/GamePage.jsx'

function PrivateRoute({ children }) {
  const { user, loading } = useAuth()
  if (loading) return <div style={{ padding: '2rem', textAlign: 'center' }}>Carregando...</div>
  return user ? children : <Navigate to="/login" replace />
}

export default function AppRouter() {
  return (
    <BrowserRouter basename="/react">
      <Routes>
        {/* Rota pública: login redireciona para o HTML estático existente */}
        <Route path="/login" element={<Navigate to="/login.html" replace />} />

        {/* Rotas protegidas */}
        <Route path="/" element={<PrivateRoute><Home /></PrivateRoute>} />
        <Route path="/games/:gameId" element={<PrivateRoute><GamePage /></PrivateRoute>} />

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
