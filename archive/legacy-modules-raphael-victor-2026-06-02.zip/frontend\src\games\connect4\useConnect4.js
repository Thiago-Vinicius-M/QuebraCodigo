import { useState, useCallback } from 'react'
import { connect4 } from '../../services/gameService.js'

/**
 * useConnect4 — hook que encapsula toda a comunicação com o backend.
 * O componente Connect4.jsx só chama as funções deste hook; não chama a API diretamente.
 */
export function useConnect4() {
  const [state, setState] = useState(null)   // Connect4State do Java
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const startGame = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await connect4.start()
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Erro ao iniciar partida.')
    } finally {
      setLoading(false)
    }
  }, [])

  const makeMove = useCallback(async (col) => {
    if (!state || state.gameOver || loading) return
    setLoading(true)
    setError(null)
    try {
      const res = await connect4.move(state.gameId, col)
      setState(res.data)
    } catch (e) {
      setError(e.response?.data?.error ?? 'Movimento inválido.')
    } finally {
      setLoading(false)
    }
  }, [state, loading])

  const resetGame = useCallback(async () => {
    if (state?.gameId) {
      connect4.end(state.gameId).catch(() => {})
    }
    await startGame()
  }, [state, startGame])

  return { state, loading, error, startGame, makeMove, resetGame }
}
