# web-games-spring (legado — nao integrado ao build principal)

Este diretorio guarda um projeto Spring Boot antigo de jogos web (`com.webgames:web-games-spring`), com **Spring Boot 2.7.x** e **Java 11**. O codigo-fonte e o `pom.xml` estao em um caminho aninhado herdado de uma copia de ambiente:

`web-games-spring/home/ubuntu/web-games-spring/`

## Status

- **Nao** e referenciado pelo `pom.xml` na raiz do repositorio (`QuebraCodigo/pom.xml`).
- **Nao** atualize este modulo em paralelo com o codigo ativo sem revisar stack e portas; o jogo e a plataforma entregues ao usuario estao no modulo [`../app`](../app) (recursos estaticos e APIs).
- Manter este aviso evita confundir este POM com o build principal.

## Se precisar compilar localmente (apenas referencia)

```bash
cd web-games-spring/home/ubuntu/web-games-spring
mvn -f pom.xml clean verify
```

Isso e **opcional**; CI e releases devem validar apenas `app/` ate haver decisao de arquivar ou remover este legado.
