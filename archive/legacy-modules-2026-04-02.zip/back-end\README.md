# back-end (legado — nao integrado ao build principal)

Este diretorio contem um projeto Spring Boot antigo (`com.example:demo`) com **Spring Boot 3.5.x** e **Java 17**. Ele **nao** faz parte do fluxo de desenvolvimento nem do build oficial do produto QuebraCodigo.

## Status

- **Nao** e referenciado pelo `pom.xml` na raiz do repositorio (`QuebraCodigo/pom.xml`).
- **Nao** atualize este modulo em paralelo com o codigo ativo sem alinhar proposito e dependencias; evita divergencia de modelos JPA e confusao com o schema usado em `app/`.
- O artefato executavel e a API suportada pelo time estao em [`../app`](../app).

## Se precisar compilar localmente (apenas referencia)

```bash
cd back-end
mvn -f pom.xml clean verify
```

Isso e **opcional** e serve apenas para inspecionar ou migrar codigo; o deploy e os testes de integracao devem focar o modulo `app`.
